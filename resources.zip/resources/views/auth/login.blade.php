@extends('layouts.app')

@section('content')

<div id="app">
    <sign-in-sign-up>
    </sign-in-sign-up>
</div>

@endsection
