<template>
    <div class="loading">
        <img src="../../../img/loading.gif" alt="loading animation" class="loading-img">
    </div>
</template>

<script>

export default {
    
}
</script>